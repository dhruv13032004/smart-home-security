#include <WiFi.h>
#include <WebServer.h>
#include <SPIFFS.h>
#include <SPI.h>
#include <MFRC522.h>
#include <DHT.h>
#include <mbedtls/md.h>
#include <Preferences.h>

#define IR_PIN          34
#define LDR_PIN         35
#define PIR_PIN         27
#define DHT_PIN         26
#define TRIG_PIN        25
#define ECHO_PIN        33
#define RFID_SS         5
#define RFID_RST        4
#define RELAY1          16
#define RELAY2          17
#define RELAY3          18
#define RELAY4          19

#define DHT_TYPE        DHT11
#define MAX_ATTEMPTS    5
#define LOCKOUT_MS      300000
#define SESSION_MS      1800000
#define MAX_LOGS        100
#define RATE_WINDOW     60000
#define MAX_REQ         60
#define MAX_CARDS       10
#define ALERT_COOLDOWN  30000

const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";
const char* adminUser = "admin";
const char* adminHash = "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918";

WebServer server(80);
MFRC522 rfid(RFID_SS, RFID_RST);
DHT dht(DHT_PIN, DHT_TYPE);
Preferences prefs;

struct Session { String token; unsigned long created; String ip; bool valid; };
Session sess = {"", 0, "", false};

struct Log { unsigned long ts; String type; String detail; String ip; uint8_t sev; };
Log logs[MAX_LOGS];
int logIdx = 0, totalLogs = 0;

struct RateLimit { String ip; int count; unsigned long start; };
RateLimit rates[20];
int rateCount = 0;

struct LoginTrack { String ip; int attempts; unsigned long last; unsigned long lockUntil; };
LoginTrack logins[10];
int loginCount = 0;

struct Card { byte uid[4]; String name; bool active; };
Card cards[MAX_CARDS];
int cardCount = 0;

struct Sensors {
    float temp, hum;
    int ir, ldr;
    bool pir;
    float dist;
    bool r1, r2, r3, r4;
    unsigned long updated;
};
Sensors sens = {0, 0, 0, 0, false, 0, false, false, false, false, 0};

bool intrusion = false;
unsigned long lastAlert = 0;
int motionCount = 0;
bool armed = true;
unsigned long startTime = 0;
int totalReq = 0, blockedReq = 0, failedLogin = 0, successLogin = 0;

String sha256(String data) {
    byte hash[32];
    mbedtls_md_context_t ctx;
    mbedtls_md_init(&ctx);
    mbedtls_md_setup(&ctx, mbedtls_md_info_from_type(MBEDTLS_MD_SHA256), 0);
    mbedtls_md_starts(&ctx);
    mbedtls_md_update(&ctx, (const unsigned char*)data.c_str(), data.length());
    mbedtls_md_finish(&ctx, hash);
    mbedtls_md_free(&ctx);
    String out = "";
    for(int i=0; i<32; i++) {
        if(hash[i]<16) out += "0";
        out += String(hash[i], HEX);
    }
    return out;
}

String genToken() {
    String t = "";
    for(int i=0; i<32; i++) t += String(random(0,16), HEX);
    return sha256(t + String(millis()) + String(esp_random()));
}

String getIP() { return server.client().remoteIP().toString(); }
unsigned long uptime() { return millis() - startTime; }

String fmtTime(unsigned long ms) {
    unsigned long s = ms/1000, m = s/60, h = m/60, d = h/24;
    return String(d)+"d "+String(h%24)+"h "+String(m%60)+"m "+String(s%60)+"s";
}

String esc(String in) {
    in.replace("&","&amp;"); in.replace("<","&lt;"); in.replace(">","&gt;");
    in.replace("\"","&quot;"); in.replace("'","&#x27;");
    return in;
}

void addLog(String type, String detail, String ip, uint8_t sev) {
    logs[logIdx].ts = millis();
    logs[logIdx].type = type;
    logs[logIdx].detail = detail;
    logs[logIdx].ip = ip;
    logs[logIdx].sev = sev;
    logIdx = (logIdx+1) % MAX_LOGS;
    if(totalLogs < MAX_LOGS) totalLogs++;
    if(sev >= 2) {
        Serial.print("[SEC] "); Serial.print(type); Serial.print(": ");
        Serial.print(detail); Serial.print(" from "); Serial.println(ip);
    }
}

bool checkRate(String ip) {
    unsigned long now = millis();
    int idx = -1;
    for(int i=0; i<rateCount; i++) if(rates[i].ip == ip) { idx = i; break; }
    if(idx == -1) {
        if(rateCount >= 20) { for(int i=0; i<19; i++) rates[i] = rates[i+1]; rateCount = 19; }
        idx = rateCount++;
        rates[idx].ip = ip; rates[idx].count = 0; rates[idx].start = now;
    }
    if(now - rates[idx].start > RATE_WINDOW) { rates[idx].count = 0; rates[idx].start = now; }
    rates[idx].count++;
    if(rates[idx].count > MAX_REQ) { addLog("RATE_LIMIT", "exceeded", ip, 2); blockedReq++; return false; }
    return true;
}

bool isLocked(String ip) {
    unsigned long now = millis();
    for(int i=0; i<loginCount; i++) if(logins[i].ip == ip && logins[i].lockUntil > now) return true;
    return false;
}

void recordLogin(String ip, bool ok) {
    unsigned long now = millis();
    int idx = -1;
    for(int i=0; i<loginCount; i++) if(logins[i].ip == ip) { idx = i; break; }
    if(idx == -1) {
        if(loginCount >= 10) { for(int i=0; i<9; i++) logins[i] = logins[i+1]; loginCount = 9; }
        idx = loginCount++;
        logins[idx].ip = ip; logins[idx].attempts = 0; logins[idx].lockUntil = 0;
    }
    if(ok) { logins[idx].attempts = 0; logins[idx].lockUntil = 0; successLogin++; }
    else {
        logins[idx].attempts++; logins[idx].last = now; failedLogin++;
        if(logins[idx].attempts >= MAX_ATTEMPTS) {
            logins[idx].lockUntil = now + LOCKOUT_MS;
            addLog("LOCKOUT", "IP locked", ip, 3);
        }
    }
}

bool validSession(String token, String ip) {
    if(!sess.valid || sess.token != token) return false;
    if(sess.ip != ip) { addLog("HIJACK", "wrong IP", ip, 3); return false; }
    if(millis() - sess.created > SESSION_MS) { sess.valid = false; return false; }
    return true;
}

String createSession(String ip) {
    sess.token = genToken(); sess.created = millis(); sess.ip = ip; sess.valid = true;
    addLog("SESSION", "created", ip, 1);
    return sess.token;
}

void destroySession() { addLog("SESSION", "destroyed", sess.ip, 1); sess.valid = false; sess.token = ""; }

bool isAuth() {
    if(!server.hasHeader("Cookie")) return false;
    String cookie = server.header("Cookie");
    int s = cookie.indexOf("session=");
    if(s == -1) return false;
    s += 8;
    int e = cookie.indexOf(";", s);
    if(e == -1) e = cookie.length();
    return validSession(cookie.substring(s, e), getIP());
}

void readSensors() {
    sens.temp = dht.readTemperature();
    sens.hum = dht.readHumidity();
    if(isnan(sens.temp)) sens.temp = 0;
    if(isnan(sens.hum)) sens.hum = 0;
    sens.ir = digitalRead(IR_PIN);
    sens.ldr = analogRead(LDR_PIN);
    bool pir = digitalRead(PIR_PIN);
    if(pir && !sens.pir) {
        motionCount++;
        if(armed && motionCount >= 2) triggerAlert("PIR motion");
    } else if(!pir) motionCount = 0;
    sens.pir = pir;
    digitalWrite(TRIG_PIN, LOW); delayMicroseconds(2);
    digitalWrite(TRIG_PIN, HIGH); delayMicroseconds(10);
    digitalWrite(TRIG_PIN, LOW);
    long dur = pulseIn(ECHO_PIN, HIGH, 30000);
    sens.dist = dur * 0.034 / 2;
    if(sens.dist < 50 && sens.dist > 0 && armed) triggerAlert("Proximity: " + String(sens.dist) + "cm");
    sens.updated = millis();
}

void triggerAlert(String reason) {
    if(millis() - lastAlert < ALERT_COOLDOWN) return;
    intrusion = true; lastAlert = millis();
    addLog("INTRUSION", reason, "SENSOR", 3);
}

void loadCards() {
    prefs.begin("rfid", true);
    cardCount = prefs.getInt("count", 0);
    for(int i=0; i<cardCount && i<MAX_CARDS; i++) {
        String k = "card" + String(i);
        prefs.getBytes(k.c_str(), cards[i].uid, 4);
        cards[i].name = prefs.getString((k+"n").c_str(), "Card "+String(i));
        cards[i].active = prefs.getBool((k+"a").c_str(), true);
    }
    prefs.end();
}

void saveCards() {
    prefs.begin("rfid", false);
    prefs.putInt("count", cardCount);
    for(int i=0; i<cardCount; i++) {
        String k = "card" + String(i);
        prefs.putBytes(k.c_str(), cards[i].uid, 4);
        prefs.putString((k+"n").c_str(), cards[i].name);
        prefs.putBool((k+"a").c_str(), cards[i].active);
    }
    prefs.end();
}

bool isCardOk(byte* uid) {
    for(int i=0; i<cardCount; i++) {
        if(!cards[i].active) continue;
        bool match = true;
        for(int j=0; j<4; j++) if(cards[i].uid[j] != uid[j]) { match = false; break; }
        if(match) return true;
    }
    return false;
}

String uidStr(byte* uid) {
    String s = "";
    for(int i=0; i<4; i++) { if(uid[i]<16) s += "0"; s += String(uid[i], HEX); }
    s.toUpperCase();
    return s;
}

void checkRFID() {
    if(!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) return;
    String uid = uidStr(rfid.uid.uidByte);
    if(isCardOk(rfid.uid.uidByte)) {
        addLog("RFID_OK", uid, "RFID", 1);
        armed = !armed; intrusion = false;
    } else addLog("RFID_DENY", uid, "RFID", 3);
    rfid.PICC_HaltA(); rfid.PCD_StopCrypto1();
}

void setRelay(int n, bool state) {
    int pin; bool* st;
    switch(n) {
        case 1: pin=RELAY1; st=&sens.r1; break;
        case 2: pin=RELAY2; st=&sens.r2; break;
        case 3: pin=RELAY3; st=&sens.r3; break;
        case 4: pin=RELAY4; st=&sens.r4; break;
        default: return;
    }
    digitalWrite(pin, state ? LOW : HIGH);
    *st = state;
    addLog("RELAY", "R"+String(n)+" "+(state?"ON":"OFF"), getIP(), 1);
}

void sendHeaders() {
    server.sendHeader("X-Content-Type-Options", "nosniff");
    server.sendHeader("X-Frame-Options", "DENY");
    server.sendHeader("X-XSS-Protection", "1; mode=block");
    server.sendHeader("Cache-Control", "no-store");
}

void handleRoot() {
    totalReq++;
    String ip = getIP();
    if(!checkRate(ip)) { server.send(429, "text/plain", "Too Many Requests"); return; }
    if(!isAuth()) { server.sendHeader("Location", "/login"); server.send(302); return; }
    sendHeaders();

    String h = "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Smart Home</title><style>";
    h += "*{box-sizing:border-box;margin:0;padding:0}body{font-family:monospace;background:#1a1a1a;color:#0f0;padding:10px;font-size:14px}";
    h += ".container{max-width:1200px;margin:0 auto}h1,h2{border-bottom:1px solid #0f0;padding-bottom:5px;margin-bottom:10px}h1{font-size:18px}h2{font-size:14px;margin-top:20px}";
    h += ".grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:10px;margin-top:10px}.box{border:1px solid #0f0;padding:10px;background:#0a0a0a}";
    h += ".row{display:flex;justify-content:space-between;padding:3px 0;border-bottom:1px dotted #030}.label{color:#080}.value{color:#0f0}.critical{color:#f00}.warning{color:#ff0}.ok{color:#0f0}";
    h += "button{background:#030;color:#0f0;border:1px solid #0f0;padding:5px 10px;cursor:pointer;font-family:monospace;margin:2px}button:hover{background:#050}button.on{background:#050}button.danger{border-color:#f00;color:#f00}";
    h += ".status-bar{display:flex;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:10px;padding:5px;border:1px solid #0f0}nav{margin:10px 0}nav a{color:#0f0;margin-right:15px}";
    h += ".log-entry{padding:3px 0;border-bottom:1px dotted #030;font-size:12px}.log-time{color:#080}</style></head><body><div class=\"container\">";
    h += "<h1>[ SMART HOME SECURITY ]</h1><div class=\"status-bar\"><span>System: <span class=\"ok\">ONLINE</span></span>";
    h += "<span>Security: <span class=\"" + String(armed?"ok\">ARMED":"warning\">DISARMED") + "</span></span>";
    h += "<span>Intrusion: <span class=\"" + String(intrusion?"critical\">DETECTED":"ok\">NONE") + "</span></span>";
    h += "<span>Uptime: " + fmtTime(uptime()) + "</span></div>";
    h += "<nav>[<a href=\"/\">Dashboard</a>][<a href=\"/logs\">Logs</a>][<a href=\"/rfid\">RFID</a>][<a href=\"/stats\">Stats</a>][<a href=\"/logout\">Logout</a>]</nav>";
    h += "<div class=\"grid\"><div class=\"box\"><h2>[ ENVIRONMENT ]</h2>";
    h += "<div class=\"row\"><span class=\"label\">Temperature:</span><span class=\"value\">" + String(sens.temp,1) + " C</span></div>";
    h += "<div class=\"row\"><span class=\"label\">Humidity:</span><span class=\"value\">" + String(sens.hum,1) + " %</span></div>";
    h += "<div class=\"row\"><span class=\"label\">Light:</span><span class=\"value\">" + String(sens.ldr) + "</span></div></div>";
    h += "<div class=\"box\"><h2>[ SECURITY ]</h2>";
    h += "<div class=\"row\"><span class=\"label\">PIR:</span><span class=\"value " + String(sens.pir?"critical":"ok") + "\">" + String(sens.pir?"DETECTED":"CLEAR") + "</span></div>";
    h += "<div class=\"row\"><span class=\"label\">IR:</span><span class=\"value\">" + String(sens.ir?"TRIGGERED":"CLEAR") + "</span></div>";
    h += "<div class=\"row\"><span class=\"label\">Proximity:</span><span class=\"value\">" + String(sens.dist,1) + " cm</span></div></div>";
    h += "<div class=\"box\"><h2>[ RELAYS ]</h2>";
    h += "<div class=\"row\"><span class=\"label\">Relay 1:</span><button class=\"" + String(sens.r1?"on":"") + "\" onclick=\"toggleR(1)\">" + String(sens.r1?"ON":"OFF") + "</button></div>";
    h += "<div class=\"row\"><span class=\"label\">Relay 2:</span><button class=\"" + String(sens.r2?"on":"") + "\" onclick=\"toggleR(2)\">" + String(sens.r2?"ON":"OFF") + "</button></div>";
    h += "<div class=\"row\"><span class=\"label\">Relay 3:</span><button class=\"" + String(sens.r3?"on":"") + "\" onclick=\"toggleR(3)\">" + String(sens.r3?"ON":"OFF") + "</button></div>";
    h += "<div class=\"row\"><span class=\"label\">Relay 4:</span><button class=\"" + String(sens.r4?"on":"") + "\" onclick=\"toggleR(4)\">" + String(sens.r4?"ON":"OFF") + "</button></div></div>";
    h += "<div class=\"box\"><h2>[ CONTROL ]</h2>";
    h += "<div class=\"row\"><span class=\"label\">Arm:</span><button onclick=\"toggleArm()\">" + String(armed?"DISARM":"ARM") + "</button></div>";
    h += "<div class=\"row\"><span class=\"label\">Alert:</span><button class=\"danger\" onclick=\"clearAlert()\">CLEAR</button></div></div></div>";
    h += "<h2>[ RECENT LOGS ]</h2><div class=\"box\" id=\"logs\">";
    
    int show = min(5, totalLogs);
    for(int i=0; i<show; i++) {
        int idx = (logIdx-1-i+MAX_LOGS) % MAX_LOGS;
        String sev = logs[idx].sev==3 ? "critical" : (logs[idx].sev==2 ? "warning" : "");
        h += "<div class=\"log-entry\"><span class=\"log-time\">[" + String(logs[idx].ts/1000) + "s]</span> ";
        h += "<span class=\"" + sev + "\">[" + esc(logs[idx].type) + "]</span> ";
        h += esc(logs[idx].detail) + " <span class=\"label\">(" + esc(logs[idx].ip) + ")</span></div>";
    }
    
    h += "</div><script>function toggleR(n){fetch('/api/relay?n='+n,{method:'POST'}).then(()=>location.reload())}";
    h += "function toggleArm(){fetch('/api/arm',{method:'POST'}).then(()=>location.reload())}";
    h += "function clearAlert(){fetch('/api/clear',{method:'POST'}).then(()=>location.reload())}";
    h += "setTimeout(()=>location.reload(),5000);</script></div></body></html>";
    
    server.send(200, "text/html", h);
}

void handleLogin() {
    totalReq++;
    String ip = getIP();
    if(!checkRate(ip)) { server.send(429, "text/plain", "Too Many Requests"); return; }
    sendHeaders();
    String err = "";
    
    if(server.method() == HTTP_POST) {
        if(isLocked(ip)) { err = "Locked. Try later."; addLog("LOGIN_BLOCK", "locked", ip, 2); }
        else {
            String user = server.arg("username");
            String pass = server.arg("password");
            if(user.length() > 32 || pass.length() > 64) { err = "Invalid input"; addLog("LOGIN_INVALID", "bad input", ip, 2); }
            else {
                if(user == adminUser && sha256(pass) == adminHash) {
                    String token = createSession(ip);
                    recordLogin(ip, true);
                    server.sendHeader("Set-Cookie", "session=" + token + "; HttpOnly; SameSite=Strict; Path=/");
                    server.sendHeader("Location", "/");
                    server.send(302);
                    return;
                } else {
                    recordLogin(ip, false);
                    addLog("LOGIN_FAIL", "bad creds: " + esc(user), ip, 2);
                    err = "Invalid credentials";
                }
            }
        }
    }
    
    String h = "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Login</title><style>";
    h += "*{box-sizing:border-box}body{font-family:monospace;background:#1a1a1a;color:#0f0;display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0}";
    h += ".login{border:1px solid #0f0;padding:20px;width:300px;background:#0a0a0a}h1{font-size:16px;text-align:center;border-bottom:1px solid #0f0;padding-bottom:10px;margin-bottom:20px}";
    h += "input{width:100%;padding:8px;margin:5px 0 15px;background:#0a0a0a;border:1px solid #0f0;color:#0f0;font-family:monospace}input:focus{outline:none;background:#010}";
    h += "button{width:100%;padding:10px;background:#030;color:#0f0;border:1px solid #0f0;cursor:pointer;font-family:monospace}button:hover{background:#050}";
    h += ".error{color:#f00;text-align:center;margin-bottom:10px;font-size:12px}label{font-size:12px;color:#080}</style></head><body><div class=\"login\"><h1>[ LOGIN ]</h1>";
    if(err != "") h += "<p class=\"error\">" + esc(err) + "</p>";
    h += "<form method=\"POST\"><label>USERNAME:</label><input type=\"text\" name=\"username\" required maxlength=\"32\" autocomplete=\"off\">";
    h += "<label>PASSWORD:</label><input type=\"password\" name=\"password\" required maxlength=\"64\"><button type=\"submit\">LOGIN</button></form></div></body></html>";
    
    server.send(200, "text/html", h);
}

void handleLogout() {
    destroySession();
    server.sendHeader("Set-Cookie", "session=; Max-Age=0; Path=/");
    server.sendHeader("Location", "/login");
    server.send(302);
}

void handleLogs() {
    totalReq++;
    String ip = getIP();
    if(!checkRate(ip)) { server.send(429, "text/plain", "Too Many Requests"); return; }
    if(!isAuth()) { server.sendHeader("Location", "/login"); server.send(302); return; }
    sendHeaders();
    
    String h = "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Logs</title><style>";
    h += "*{box-sizing:border-box;margin:0;padding:0}body{font-family:monospace;background:#1a1a1a;color:#0f0;padding:10px;font-size:12px}";
    h += ".container{max-width:1200px;margin:0 auto}h1{font-size:18px;border-bottom:1px solid #0f0;padding-bottom:5px;margin-bottom:10px}";
    h += "nav{margin:10px 0}nav a{color:#0f0;margin-right:15px}table{width:100%;border-collapse:collapse;margin-top:10px}";
    h += "th,td{border:1px solid #030;padding:5px;text-align:left}th{background:#030}.critical{color:#f00}.warning{color:#ff0}.info{color:#0f0}";
    h += "</style></head><body><div class=\"container\"><h1>[ SECURITY LOGS ]</h1>";
    h += "<nav>[<a href=\"/\">Dashboard</a>][<a href=\"/logs\">Logs</a>][<a href=\"/rfid\">RFID</a>][<a href=\"/stats\">Stats</a>][<a href=\"/logout\">Logout</a>]</nav>";
    h += "<p>Total: " + String(totalLogs) + "</p><table><tr><th>Time</th><th>Sev</th><th>Event</th><th>Details</th><th>IP</th></tr>";
    
    for(int i=0; i<totalLogs && i<MAX_LOGS; i++) {
        int idx = (logIdx-1-i+MAX_LOGS) % MAX_LOGS;
        String cls = logs[idx].sev==3 ? "critical" : (logs[idx].sev==2 ? "warning" : "info");
        String sev = logs[idx].sev==3 ? "CRIT" : (logs[idx].sev==2 ? "WARN" : "INFO");
        h += "<tr><td>" + String(logs[idx].ts/1000) + "</td><td class=\"" + cls + "\">" + sev + "</td>";
        h += "<td>" + esc(logs[idx].type) + "</td><td>" + esc(logs[idx].detail) + "</td><td>" + esc(logs[idx].ip) + "</td></tr>";
    }
    h += "</table></div></body></html>";
    server.send(200, "text/html", h);
}

void handleRfid() {
    totalReq++;
    String ip = getIP();
    if(!checkRate(ip)) { server.send(429, "text/plain", "Too Many Requests"); return; }
    if(!isAuth()) { server.sendHeader("Location", "/login"); server.send(302); return; }
    sendHeaders();
    String msg = "";
    
    if(server.method() == HTTP_POST) {
        String action = server.arg("action");
        if(action == "add" && cardCount < MAX_CARDS) {
            String uid = server.arg("uid");
            String name = server.arg("name");
            if(uid.length() == 8 && name.length() <= 20) {
                for(int i=0; i<4; i++) cards[cardCount].uid[i] = strtol(uid.substring(i*2, i*2+2).c_str(), NULL, 16);
                cards[cardCount].name = name;
                cards[cardCount].active = true;
                cardCount++;
                saveCards();
                addLog("RFID_ADD", uid, ip, 1);
                msg = "Card added";
            } else msg = "Invalid input";
        } else if(action == "delete") {
            int idx = server.arg("idx").toInt();
            if(idx >= 0 && idx < cardCount) {
                addLog("RFID_DEL", uidStr(cards[idx].uid), ip, 2);
                for(int i=idx; i<cardCount-1; i++) cards[i] = cards[i+1];
                cardCount--;
                saveCards();
                msg = "Deleted";
            }
        } else if(action == "toggle") {
            int idx = server.arg("idx").toInt();
            if(idx >= 0 && idx < cardCount) {
                cards[idx].active = !cards[idx].active;
                saveCards();
                addLog("RFID_TOGGLE", uidStr(cards[idx].uid) + " " + (cards[idx].active?"ON":"OFF"), ip, 1);
                msg = "Updated";
            }
        }
    }
    
    String h = "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>RFID</title><style>";
    h += "*{box-sizing:border-box;margin:0;padding:0}body{font-family:monospace;background:#1a1a1a;color:#0f0;padding:10px;font-size:14px}";
    h += ".container{max-width:800px;margin:0 auto}h1,h2{border-bottom:1px solid #0f0;padding-bottom:5px;margin-bottom:10px}h1{font-size:18px}h2{font-size:14px;margin-top:20px}";
    h += "nav{margin:10px 0}nav a{color:#0f0;margin-right:15px}table{width:100%;border-collapse:collapse;margin-top:10px}";
    h += "th,td{border:1px solid #030;padding:8px;text-align:left}th{background:#030}input{background:#0a0a0a;color:#0f0;border:1px solid #0f0;padding:5px;font-family:monospace;margin:5px 0}";
    h += "button{background:#030;color:#0f0;border:1px solid #0f0;padding:5px 10px;cursor:pointer;font-family:monospace;margin:2px}button:hover{background:#050}button.danger{border-color:#f00;color:#f00}";
    h += ".msg{padding:10px;margin:10px 0;border:1px solid #0f0}.inactive{color:#666}.form-box{border:1px solid #0f0;padding:15px;margin-top:15px;background:#0a0a0a}";
    h += "</style></head><body><div class=\"container\"><h1>[ RFID CARDS ]</h1>";
    h += "<nav>[<a href=\"/\">Dashboard</a>][<a href=\"/logs\">Logs</a>][<a href=\"/rfid\">RFID</a>][<a href=\"/stats\">Stats</a>][<a href=\"/logout\">Logout</a>]</nav>";
    if(msg != "") h += "<div class=\"msg\">" + esc(msg) + "</div>";
    h += "<table><tr><th>#</th><th>UID</th><th>Name</th><th>Status</th><th>Actions</th></tr>";
    
    for(int i=0; i<cardCount; i++) {
        h += "<tr class=\"" + String(cards[i].active?"":"inactive") + "\"><td>" + String(i+1) + "</td>";
        h += "<td>" + uidStr(cards[i].uid) + "</td><td>" + esc(cards[i].name) + "</td>";
        h += "<td>" + String(cards[i].active?"ACTIVE":"INACTIVE") + "</td><td>";
        h += "<form method=\"POST\" style=\"display:inline\"><input type=\"hidden\" name=\"action\" value=\"toggle\"><input type=\"hidden\" name=\"idx\" value=\"" + String(i) + "\">";
        h += "<button type=\"submit\">" + String(cards[i].active?"Disable":"Enable") + "</button></form> ";
        h += "<form method=\"POST\" style=\"display:inline\" onsubmit=\"return confirm('Delete?')\"><input type=\"hidden\" name=\"action\" value=\"delete\">";
        h += "<input type=\"hidden\" name=\"idx\" value=\"" + String(i) + "\"><button type=\"submit\" class=\"danger\">Del</button></form></td></tr>";
    }
    
    h += "</table><div class=\"form-box\"><h2>[ ADD CARD ]</h2><form method=\"POST\"><input type=\"hidden\" name=\"action\" value=\"add\">";
    h += "<label>UID: </label><input type=\"text\" name=\"uid\" pattern=\"[0-9A-Fa-f]{8}\" maxlength=\"8\" required placeholder=\"A1B2C3D4\">";
    h += "<label>Name: </label><input type=\"text\" name=\"name\" maxlength=\"20\" required placeholder=\"Name\">";
    h += "<button type=\"submit\">Add</button></form></div><p style=\"margin-top:15px;font-size:12px;color:#080\">Cards: " + String(cardCount) + "/" + String(MAX_CARDS) + "</p></div></body></html>";
    
    server.send(200, "text/html", h);
}

void handleStats() {
    totalReq++;
    String ip = getIP();
    if(!checkRate(ip)) { server.send(429, "text/plain", "Too Many Requests"); return; }
    if(!isAuth()) { server.sendHeader("Location", "/login"); server.send(302); return; }
    sendHeaders();
    
    String h = "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Stats</title><style>";
    h += "*{box-sizing:border-box;margin:0;padding:0}body{font-family:monospace;background:#1a1a1a;color:#0f0;padding:10px;font-size:14px}";
    h += ".container{max-width:800px;margin:0 auto}h1,h2{border-bottom:1px solid #0f0;padding-bottom:5px;margin-bottom:10px}h1{font-size:18px}h2{font-size:14px;margin-top:20px}";
    h += "nav{margin:10px 0}nav a{color:#0f0;margin-right:15px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px;margin-top:10px}";
    h += ".box{border:1px solid #0f0;padding:10px;background:#0a0a0a}.row{display:flex;justify-content:space-between;padding:3px 0;border-bottom:1px dotted #030}";
    h += ".label{color:#080}.value{color:#0f0}.critical{color:#f00}.warning{color:#ff0}</style></head><body><div class=\"container\"><h1>[ STATISTICS ]</h1>";
    h += "<nav>[<a href=\"/\">Dashboard</a>][<a href=\"/logs\">Logs</a>][<a href=\"/rfid\">RFID</a>][<a href=\"/stats\">Stats</a>][<a href=\"/logout\">Logout</a>]</nav>";
    h += "<div class=\"grid\"><div class=\"box\"><h2>[ SYSTEM ]</h2>";
    h += "<div class=\"row\"><span class=\"label\">Uptime:</span><span class=\"value\">" + fmtTime(uptime()) + "</span></div>";
    h += "<div class=\"row\"><span class=\"label\">Heap:</span><span class=\"value\">" + String(ESP.getFreeHeap()) + " B</span></div>";
    h += "<div class=\"row\"><span class=\"label\">CPU:</span><span class=\"value\">" + String(ESP.getCpuFreqMHz()) + " MHz</span></div>";
    h += "<div class=\"row\"><span class=\"label\">RSSI:</span><span class=\"value\">" + String(WiFi.RSSI()) + " dBm</span></div></div>";
    h += "<div class=\"box\"><h2>[ NETWORK ]</h2>";
    h += "<div class=\"row\"><span class=\"label\">IP:</span><span class=\"value\">" + WiFi.localIP().toString() + "</span></div>";
    h += "<div class=\"row\"><span class=\"label\">MAC:</span><span class=\"value\">" + WiFi.macAddress() + "</span></div>";
    h += "<div class=\"row\"><span class=\"label\">Gateway:</span><span class=\"value\">" + WiFi.gatewayIP().toString() + "</span></div></div>";
    h += "<div class=\"box\"><h2>[ REQUESTS ]</h2>";
    h += "<div class=\"row\"><span class=\"label\">Total:</span><span class=\"value\">" + String(totalReq) + "</span></div>";
    h += "<div class=\"row\"><span class=\"label\">Blocked:</span><span class=\"" + String(blockedReq>0?"warning":"value") + "\">" + String(blockedReq) + "</span></div>";
    h += "<div class=\"row\"><span class=\"label\">Req/min:</span><span class=\"value\">" + String((float)totalReq/(uptime()/60000.0),2) + "</span></div></div>";
    h += "<div class=\"box\"><h2>[ AUTH ]</h2>";
    h += "<div class=\"row\"><span class=\"label\">Success:</span><span class=\"value\">" + String(successLogin) + "</span></div>";
    h += "<div class=\"row\"><span class=\"label\">Failed:</span><span class=\"" + String(failedLogin>0?"critical":"value") + "\">" + String(failedLogin) + "</span></div>";
    h += "<div class=\"row\"><span class=\"label\">Session:</span><span class=\"value\">" + String(sess.valid?"Active":"None") + "</span></div></div>";
    h += "<div class=\"box\"><h2>[ SECURITY ]</h2>";
    h += "<div class=\"row\"><span class=\"label\">Logs:</span><span class=\"value\">" + String(totalLogs) + "</span></div>";
    h += "<div class=\"row\"><span class=\"label\">Cards:</span><span class=\"value\">" + String(cardCount) + "</span></div>";
    h += "<div class=\"row\"><span class=\"label\">Armed:</span><span class=\"value\">" + String(armed?"Yes":"No") + "</span></div>";
    h += "<div class=\"row\"><span class=\"label\">Intrusion:</span><span class=\"" + String(intrusion?"critical":"value") + "\">" + String(intrusion?"YES":"No") + "</span></div></div></div></div></body></html>";
    
    server.send(200, "text/html", h);
}

void handleApiRelay() {
    totalReq++;
    String ip = getIP();
    if(!checkRate(ip)) { server.send(429, "text/plain", "Rate limited"); return; }
    if(!isAuth()) { server.send(401, "text/plain", "Unauthorized"); addLog("API_UNAUTH", "relay", ip, 2); return; }
    int n = server.arg("n").toInt();
    if(n<1 || n>4) { server.send(400, "text/plain", "Invalid"); return; }
    bool* st;
    switch(n) { case 1: st=&sens.r1; break; case 2: st=&sens.r2; break; case 3: st=&sens.r3; break; case 4: st=&sens.r4; break; }
    setRelay(n, !(*st));
    server.send(200, "text/plain", "OK");
}

void handleApiArm() {
    totalReq++;
    String ip = getIP();
    if(!checkRate(ip)) { server.send(429, "text/plain", "Rate limited"); return; }
    if(!isAuth()) { server.send(401, "text/plain", "Unauthorized"); return; }
    armed = !armed;
    addLog("ARM", armed?"ARMED":"DISARMED", ip, 2);
    server.send(200, "text/plain", "OK");
}

void handleApiClear() {
    totalReq++;
    String ip = getIP();
    if(!checkRate(ip)) { server.send(429, "text/plain", "Rate limited"); return; }
    if(!isAuth()) { server.send(401, "text/plain", "Unauthorized"); return; }
    intrusion = false;
    motionCount = 0;
    addLog("CLEAR", "alert cleared", ip, 1);
    server.send(200, "text/plain", "OK");
}

void handleApiSensors() {
    totalReq++;
    String ip = getIP();
    if(!checkRate(ip)) { server.send(429, "application/json", "{\"error\":\"rate\"}"); return; }
    if(!isAuth()) { server.send(401, "application/json", "{\"error\":\"auth\"}"); return; }
    String j = "{\"temp\":" + String(sens.temp,1) + ",\"hum\":" + String(sens.hum,1) + ",\"ir\":" + String(sens.ir);
    j += ",\"ldr\":" + String(sens.ldr) + ",\"pir\":" + String(sens.pir?"true":"false") + ",\"dist\":" + String(sens.dist,1);
    j += ",\"r1\":" + String(sens.r1?"true":"false") + ",\"r2\":" + String(sens.r2?"true":"false");
    j += ",\"r3\":" + String(sens.r3?"true":"false") + ",\"r4\":" + String(sens.r4?"true":"false");
    j += ",\"armed\":" + String(armed?"true":"false") + ",\"intrusion\":" + String(intrusion?"true":"false") + "}";
    server.send(200, "application/json", j);
}

void handle404() {
    totalReq++;
    addLog("404", server.uri(), getIP(), 1);
    server.send(404, "text/plain", "Not Found");
}

void setup() {
    Serial.begin(115200);
    Serial.println("\nStarting...");
    startTime = millis();
    
    pinMode(IR_PIN, INPUT);
    pinMode(PIR_PIN, INPUT);
    pinMode(TRIG_PIN, OUTPUT);
    pinMode(ECHO_PIN, INPUT);
    pinMode(RELAY1, OUTPUT);
    pinMode(RELAY2, OUTPUT);
    pinMode(RELAY3, OUTPUT);
    pinMode(RELAY4, OUTPUT);
    
    digitalWrite(RELAY1, HIGH);
    digitalWrite(RELAY2, HIGH);
    digitalWrite(RELAY3, HIGH);
    digitalWrite(RELAY4, HIGH);
    
    dht.begin();
    SPI.begin();
    rfid.PCD_Init();
    loadCards();
    
    WiFi.begin(ssid, password);
    WiFi.setHostname("SmartHome");
    int tries = 0;
    while(WiFi.status() != WL_CONNECTED && tries < 30) { delay(500); Serial.print("."); tries++; }
    
    if(WiFi.status() == WL_CONNECTED) {
        Serial.println("\nWiFi OK");
        Serial.print("IP: "); Serial.println(WiFi.localIP());
    } else Serial.println("\nWiFi Failed");
    
    server.on("/", handleRoot);
    server.on("/login", handleLogin);
    server.on("/logout", handleLogout);
    server.on("/logs", handleLogs);
    server.on("/rfid", handleRfid);
    server.on("/stats", handleStats);
    server.on("/api/relay", HTTP_POST, handleApiRelay);
    server.on("/api/arm", HTTP_POST, handleApiArm);
    server.on("/api/clear", HTTP_POST, handleApiClear);
    server.on("/api/sensors", handleApiSensors);
    server.onNotFound(handle404);
    
    const char* hdrs[] = {"Cookie"};
    server.collectHeaders(hdrs, 1);
    server.begin();
    
    addLog("START", "system up", "SYS", 1);
    Serial.println("Ready - http://" + WiFi.localIP().toString());
}

void loop() {
    server.handleClient();
    
    static unsigned long lastSensor = 0;
    if(millis() - lastSensor > 2000) { readSensors(); lastSensor = millis(); }
    
    static unsigned long lastRfid = 0;
    if(millis() - lastRfid > 100) { checkRFID(); lastRfid = millis(); }
    
    static unsigned long lastWifi = 0;
    if(millis() - lastWifi > 30000) {
        if(WiFi.status() != WL_CONNECTED) { addLog("WIFI", "reconnecting", "SYS", 2); WiFi.reconnect(); }
        lastWifi = millis();
    }
    
    delay(10);
}
