# Security Hardening Checklist

## Pre-Deployment Checklist

### [ ] Password Security
- [ ] Changed default admin password from "admin"
- [ ] Generated SHA-256 hash for new password
- [ ] Password is at least 12 characters
- [ ] Password contains uppercase, lowercase, numbers, symbols
- [ ] Password is not used elsewhere

### [ ] WiFi Security
- [ ] Using WPA2/WPA3 encryption
- [ ] WiFi password is strong
- [ ] Hidden SSID (optional)
- [ ] MAC filtering enabled (optional)

### [ ] Network Security
- [ ] ESP32 on separate IoT VLAN (recommended)
- [ ] Firewall rules configured
- [ ] No port forwarding for this device
- [ ] UPnP disabled on router

### [ ] Physical Security
- [ ] Device in secured location
- [ ] Sensors positioned correctly
- [ ] RFID reader accessible but protected
- [ ] Reset button not easily accessible

## Security Configuration Values

```cpp
// Adjust these in the code based on your security needs:

#define MAX_LOGIN_ATTEMPTS  5      // Lower = more secure, but more lockouts
#define LOCKOUT_TIME        300000 // 5 min, increase for more security
#define SESSION_TIMEOUT     1800000 // 30 min, decrease for more security
#define RATE_LIMIT_WINDOW   60000   // 1 minute window
#define MAX_REQUESTS        60      // Requests per window
#define INTRUSION_COOLDOWN  30000   // Time between alerts
```

## Understanding the Security Logs

### Severity Levels

| Level | Color | Meaning | Action Required |
|-------|-------|---------|-----------------|
| INFO | Green | Normal operations | None |
| WARNING | Yellow | Suspicious activity | Monitor |
| CRITICAL | Red | Security breach attempt | Investigate immediately |

### Common Attack Patterns to Watch

1. **Brute Force Attack**
   - Multiple LOGIN_FAILED from same IP
   - LOCKOUT events
   - Action: IP may be attacker, consider blocking

2. **Session Hijacking Attempt**
   - SESSION_HIJACK events
   - Action: Token compromised, check network security

3. **DoS Attack**
   - Multiple RATE_LIMIT from same IP
   - Blocked requests increasing rapidly
   - Action: IP flooding server

4. **RFID Cloning Attempt**
   - Multiple RFID_DENIED events
   - Unknown UIDs appearing
   - Action: Someone testing stolen/cloned cards

5. **Reconnaissance**
   - Multiple 404_NOT_FOUND events
   - Same IP scanning different paths
   - Action: Attacker probing for vulnerabilities

## Security Monitoring Routine

### Daily
- [ ] Check /stats for unusual request counts
- [ ] Review last 10 security logs
- [ ] Verify no unknown RFID cards added

### Weekly
- [ ] Review all CRITICAL events
- [ ] Check for repeated WARNING events
- [ ] Verify RFID card list is accurate
- [ ] Test one sensor for functionality

### Monthly
- [ ] Review all security logs
- [ ] Update password if needed
- [ ] Check for firmware updates
- [ ] Test intrusion detection system
- [ ] Verify all RFID cards still needed

## Incident Response

### If You See Unauthorized Access

1. **Immediate Actions:**
   - Note the source IP address
   - Take screenshot of logs
   - Disable remote access if enabled

2. **Investigation:**
   - Check if IP is internal or external
   - Review all recent logs
   - Check RFID card access history

3. **Remediation:**
   - Change admin password immediately
   - Revoke all sessions (restart ESP32)
   - Remove any unauthorized RFID cards
   - Block suspicious IPs at router

4. **Prevention:**
   - Increase security settings
   - Consider additional monitoring
   - Review network security

### If Device Is Compromised

1. **Disconnect from network immediately**
2. **Do not use until secured**
3. **Reflash firmware**
4. **Change all passwords**
5. **Generate new RFID card list**
6. **Review router/network security**

## Password Hash Generator (Python)

Save and run this script to generate password hashes:

```python
#!/usr/bin/env python3
import hashlib
import getpass

def generate_hash():
    print("ESP32 Smart Home - Password Hash Generator")
    print("-" * 40)
    
    password = getpass.getpass("Enter new password: ")
    confirm = getpass.getpass("Confirm password: ")
    
    if password != confirm:
        print("ERROR: Passwords do not match!")
        return
    
    if len(password) < 8:
        print("WARNING: Password should be at least 8 characters")
    
    hash_value = hashlib.sha256(password.encode()).hexdigest()
    
    print("\n" + "=" * 40)
    print("Your password hash:")
    print(hash_value)
    print("=" * 40)
    print("\nReplace this line in the code:")
    print(f'const char* ADMIN_PASSWORD_HASH = "{hash_value}";')

if __name__ == "__main__":
    generate_hash()
```

## Network Diagram (Recommended Setup)

```
Internet
    │
    ▼
┌──────────┐
│  Router  │
│ Firewall │
└────┬─────┘
     │
     ├─────────────────┬──────────────────┐
     │                 │                  │
     ▼                 ▼                  ▼
┌─────────┐     ┌─────────────┐     ┌──────────┐
│ Main    │     │ IoT VLAN    │     │ Guest    │
│ Network │     │ (Isolated)  │     │ Network  │
└─────────┘     └──────┬──────┘     └──────────┘
                       │
                       ▼
                ┌──────────────┐
                │   ESP32      │
                │ Smart Home   │
                │   System     │
                └──────────────┘
```

## Firewall Rules (Example for pfSense/OPNsense)

```
# Block IoT to Main LAN
Block  IoT_Net -> Main_LAN  any

# Allow Main LAN to access IoT web interface
Pass   Main_LAN -> IoT_Net  TCP 80

# Allow IoT to internet for time sync (optional)
Pass   IoT_Net -> any       UDP 123 (NTP)

# Block all other IoT outbound
Block  IoT_Net -> any       any
```

## Security vs Convenience Trade-offs

| Setting | More Secure | More Convenient |
|---------|-------------|-----------------|
| Login attempts | 3 | 10 |
| Lockout time | 30 min | 1 min |
| Session timeout | 5 min | 2 hours |
| Rate limit | 30/min | 120/min |
| Intrusion cooldown | 5 min | 10 sec |

Choose settings based on your environment and threat model.
