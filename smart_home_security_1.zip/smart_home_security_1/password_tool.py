#!/usr/bin/env python3
"""
Password Hash Generator for ESP32 Smart Home Security System
Generates SHA-256 hashes for use in the Arduino code.
"""

import hashlib
import getpass
import sys
import re


def check_password_strength(password):
    """Check password strength and return score and feedback."""
    score = 0
    feedback = []
    
    # Length checks
    if len(password) >= 8:
        score += 1
    else:
        feedback.append("- Should be at least 8 characters")
    
    if len(password) >= 12:
        score += 1
    else:
        feedback.append("- Consider using 12+ characters")
    
    if len(password) >= 16:
        score += 1
    
    # Character type checks
    if re.search(r'[a-z]', password):
        score += 1
    else:
        feedback.append("- Add lowercase letters")
    
    if re.search(r'[A-Z]', password):
        score += 1
    else:
        feedback.append("- Add uppercase letters")
    
    if re.search(r'\d', password):
        score += 1
    else:
        feedback.append("- Add numbers")
    
    if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        score += 1
    else:
        feedback.append("- Add special characters (!@#$%^&*)")
    
    # Common patterns to avoid
    common_patterns = ['password', '123456', 'admin', 'qwerty', 'letmein']
    if any(pattern in password.lower() for pattern in common_patterns):
        score -= 2
        feedback.append("- Avoid common password patterns")
    
    return score, feedback


def get_strength_label(score):
    """Convert score to human-readable strength label."""
    if score <= 2:
        return "WEAK", "\033[91m"  # Red
    elif score <= 4:
        return "MODERATE", "\033[93m"  # Yellow
    elif score <= 6:
        return "STRONG", "\033[92m"  # Green
    else:
        return "VERY STRONG", "\033[92m"  # Green


def generate_hash():
    """Main function to generate password hash."""
    print("\n" + "=" * 50)
    print("  ESP32 Smart Home - Password Hash Generator")
    print("=" * 50)
    
    # Get password
    try:
        password = getpass.getpass("\nEnter new password: ")
        if not password:
            print("\nError: Password cannot be empty!")
            return False
        
        confirm = getpass.getpass("Confirm password: ")
    except KeyboardInterrupt:
        print("\n\nCancelled.")
        return False
    
    # Verify match
    if password != confirm:
        print("\n\033[91mError: Passwords do not match!\033[0m")
        return False
    
    # Check strength
    score, feedback = check_password_strength(password)
    label, color = get_strength_label(score)
    
    print(f"\nPassword Strength: {color}{label}\033[0m ({score}/7)")
    
    if feedback:
        print("\nSuggestions for improvement:")
        for item in feedback:
            print(f"  {item}")
    
    # Warn if weak but continue
    if score <= 2:
        print("\n\033[91mWARNING: This password is weak!")
        print("Consider using a stronger password.\033[0m")
        try:
            response = input("\nContinue anyway? (y/N): ")
            if response.lower() != 'y':
                print("Cancelled.")
                return False
        except KeyboardInterrupt:
            print("\n\nCancelled.")
            return False
    
    # Generate hash
    hash_value = hashlib.sha256(password.encode()).hexdigest()
    
    # Output
    print("\n" + "=" * 50)
    print("  Generated SHA-256 Hash")
    print("=" * 50)
    print(f"\n{hash_value}")
    print("\n" + "-" * 50)
    print("Copy this line into your Arduino code:\n")
    print(f'const char* ADMIN_PASSWORD_HASH = "{hash_value}";')
    print("-" * 50)
    
    # Security reminder
    print("\n\033[93mSECURITY REMINDERS:\033[0m")
    print("1. Never share your password or this hash")
    print("2. This hash is one-way - password cannot be recovered")
    print("3. Store your password in a secure password manager")
    print("4. Change password periodically")
    
    return True


def verify_hash():
    """Verify a password against a hash."""
    print("\n" + "=" * 50)
    print("  Password Hash Verification")
    print("=" * 50)
    
    try:
        hash_to_verify = input("\nEnter the hash to verify: ").strip().lower()
        if len(hash_to_verify) != 64:
            print("\nError: Invalid hash length (should be 64 characters)")
            return
        
        password = getpass.getpass("Enter password to test: ")
    except KeyboardInterrupt:
        print("\n\nCancelled.")
        return
    
    computed_hash = hashlib.sha256(password.encode()).hexdigest()
    
    if computed_hash == hash_to_verify:
        print("\n\033[92m✓ Password matches the hash!\033[0m")
    else:
        print("\n\033[91m✗ Password does NOT match the hash.\033[0m")


def main():
    """Main entry point."""
    while True:
        print("\n" + "=" * 50)
        print("  ESP32 Smart Home Security - Password Tool")
        print("=" * 50)
        print("\n1. Generate new password hash")
        print("2. Verify password against hash")
        print("3. Exit")
        
        try:
            choice = input("\nSelect option (1-3): ").strip()
        except KeyboardInterrupt:
            print("\n\nGoodbye!")
            sys.exit(0)
        
        if choice == '1':
            generate_hash()
        elif choice == '2':
            verify_hash()
        elif choice == '3':
            print("\nGoodbye!")
            break
        else:
            print("\nInvalid option. Please select 1, 2, or 3.")


if __name__ == "__main__":
    main()
